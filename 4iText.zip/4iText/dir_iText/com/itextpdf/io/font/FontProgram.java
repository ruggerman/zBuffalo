/*
    $Id: 8a72d2c935cd4acc14e0223d5e49df14bab62146 $

    This file is part of the iText (R) project.
    Copyright (c) 1998-2016 iText Group NV
    Authors: Bruno Lowagie, Paulo Soares, et al.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License version 3
    as published by the Free Software Foundation with the addition of the
    following permission added to Section 15 as permitted in Section 7(a):
    FOR ANY PART OF THE COVERED WORK IN WHICH THE COPYRIGHT IS OWNED BY
    ITEXT GROUP. ITEXT GROUP DISCLAIMS THE WARRANTY OF NON INFRINGEMENT
    OF THIRD PARTY RIGHTS

    This program is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
    or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU Affero General Public License for more details.
    You should have received a copy of the GNU Affero General Public License
    along with this program; if not, see http://www.gnu.org/licenses or write to
    the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
    Boston, MA, 02110-1301 USA, or download the license from the following URL:
    http://itextpdf.com/terms-of-use/

    The interactive user interfaces in modified source and object code versions
    of this program must display Appropriate Legal Notices, as required under
    Section 5 of the GNU Affero General Public License.

    In accordance with Section 7(b) of the GNU Affero General Public License,
    a covered work must retain the producer line in every PDF that is created
    or manipulated using iText.

    You can be released from the requirements of the license by purchasing
    a commercial license. Buying such a license is mandatory as soon as you
    develop commercial activities involving the iText software without
    disclosing the source code of your own applications.
    These activities include: offering paid services to customers as an ASP,
    serving PDFs on the fly in a web application, shipping iText with a closed
    source product.

    For more information, please contact iText Software Corp. at this
    address: sales@itextpdf.com
 */
package com.itextpdf.io.font;

import com.itextpdf.io.IOException;
import com.itextpdf.io.font.otf.Glyph;
import com.itextpdf.io.util.FileUtil;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public abstract class FontProgram implements Serializable {

    private static final long serialVersionUID = -3488910249070253659L;

    public static final int DEFAULT_WIDTH = 1000;
    public static final int UNITS_NORMALIZATION = 1000;

    // In case Type1: char code to glyph.
    // In case TrueType: glyph index to glyph.
    protected Map<Integer, Glyph> codeToGlyph = new HashMap<>();
    protected Map<Integer, Glyph> unicodeToGlyph = new HashMap<>();
    protected boolean isFontSpecific;

    protected FontNames fontNames = new FontNames();
    protected FontMetrics fontMetrics = new FontMetrics();
    protected FontIdentification fontIdentification = new FontIdentification();

    protected int avgWidth;

    /**
     * The font's encoding name. This encoding is 'StandardEncoding' or 'AdobeStandardEncoding' for a font
     * that can be totally encoded according to the characters names. For all other names the font is treated as symbolic.
     */
    protected String encodingScheme = FontEncoding.FONT_SPECIFIC;

    protected String registry;

    public int countOfGlyphs() {
        return Math.max(codeToGlyph.size(), unicodeToGlyph.size());
    }

    public FontNames getFontNames() {
        return fontNames;
    }

    public FontMetrics getFontMetrics() {
        return fontMetrics;
    }

    public FontIdentification getFontIdentification() {
        return fontIdentification;
    }

    public String getRegistry() {
        return registry;
    }

    public abstract int getPdfFontFlags();

    public boolean isFontSpecific() {
        return isFontSpecific;
    }

    /**
     * Get glyph's width.
     *
     * @param unicode a unicode symbol or FontSpecif code.
     * @return Gets width in normalized 1000 units.
     */
    public int getWidth(int unicode) {
        Glyph glyph = getGlyph(unicode);
        return glyph != null ? glyph.getWidth() : 0;
    }

    public int getAvgWidth() {
        return avgWidth;
    }

    /**
     * Get glyph's bbox.
     *
     * @param unicode a unicode symbol or FontSpecif code.
     * @return Gets bbox in normalized 1000 units.
     */
    public int[] getCharBBox(int unicode) {
        Glyph glyph = getGlyph(unicode);
        return glyph != null ? glyph.getBbox() : null;
    }

    public Glyph getGlyph(int unicode) {
        return unicodeToGlyph.get(unicode);
    }

    // char code in case Type1 or index in case OpenType
    public Glyph getGlyphByCode(int charCode) {
        return codeToGlyph.get(charCode);
    }

    public boolean hasKernPairs() {
        return false;
    }

    /**
     * Gets the kerning between two glyphs.
     *
     * @param first  the first unicode value
     * @param second the second unicode value
     * @return the kerning to be applied
     */
    public int getKerning(int first, int second) {
        return getKerning(unicodeToGlyph.get(first), unicodeToGlyph.get(second));
    }

    /**
     * Gets the kerning between two glyphs.
     *
     * @param first  the first glyph
     * @param second the second glyph
     * @return the kerning to be applied
     */
    public abstract int getKerning(Glyph first, Glyph second);

    protected void setRegistry(String registry) {
        this.registry = registry;
    }

    /**
     * Gets the name without the modifiers Bold, Italic or BoldItalic.
     *
     * @param name the full name of the font
     * @return the name without the modifiers Bold, Italic or BoldItalic
     */
    protected static String getBaseName(String name) {
        if (name == null) {
            return null;
        }
        if (name.endsWith(",Bold")) {
            return name.substring(0, name.length() - 5);
        } else if (name.endsWith(",Italic")) {
            return name.substring(0, name.length() - 7);
        } else if (name.endsWith(",BoldItalic")) {
            return name.substring(0, name.length() - 11);
        } else {
            return name;
        }
    }

    protected void setTypoAscender(int ascender) {
        fontMetrics.setTypoAscender(ascender);
    }

    protected void setTypoDescender(int descender) {
        fontMetrics.setTypoDescender(descender);
    }

    protected void setCapHeight(int capHeight) {
        fontMetrics.setCapHeight(capHeight);
    }

    protected void setXHeight(int xHeight) {
        fontMetrics.setXHeight(xHeight);
    }

    protected void setItalicAngle(int italicAngle) {
        fontMetrics.setItalicAngle(italicAngle);
    }

    protected void setStemV(int stemV) {
        fontMetrics.setStemV(stemV);
    }

    protected void setStemH(int stemH) {
        fontMetrics.setStemH(stemH);
    }

    protected void setFontWeight(int fontWeight) {
        fontNames.setFontWeight(fontWeight);
    }

    protected void setFontWidth(String fontWidth) {
        fontWidth = fontWidth.toLowerCase();
        int fontWidthValue = FontNames.FWIDTH_NORMAL;
        switch (fontWidth) {
            case "ultracondensed":
                fontWidthValue = FontNames.FWIDTH_ULTRA_CONDENSED;
                break;
            case "extracondensed":
                fontWidthValue = FontNames.FWIDTH_EXTRA_CONDENSED;
                break;
            case "condensed":
                fontWidthValue = FontNames.FWIDTH_CONDENSED;
                break;
            case "semicondensed":
                fontWidthValue = FontNames.FWIDTH_SEMI_CONDENSED;
                break;
            case "normal":
                fontWidthValue = FontNames.FWIDTH_NORMAL;
                break;
            case "semiexpanded":
                fontWidthValue = FontNames.FWIDTH_SEMI_EXPANDED;
                break;
            case "expanded":
                fontWidthValue = FontNames.FWIDTH_EXPANDED;
                break;
            case "extraexpanded":
                fontWidthValue = FontNames.FWIDTH_EXTRA_EXPANDED;
                break;
            case "ultraexpanded":
                fontWidthValue = FontNames.FWIDTH_ULTRA_EXPANDED;
                break;
        }
        fontNames.setFontWidth(fontWidthValue);
    }

    protected void setFixedPitch(boolean isFixedPitch) {
        fontMetrics.setIsFixedPitch(isFixedPitch);
    }

    protected void setBold(boolean isBold) {
        if (isBold) {
            fontNames.setMacStyle(fontNames.getMacStyle() | FontNames.BOLD_FLAG);
        } else {
            fontNames.setMacStyle(fontNames.getMacStyle() & (~FontNames.BOLD_FLAG));
        }
    }

    protected void setBbox(int[] bbox) {
        fontMetrics.setBbox(bbox[0], bbox[1], bbox[2], bbox[3]);
    }

    protected void setFontFamily(String fontFamily) {
        fontNames.setFamilyName(fontFamily);
    }

    protected void setFontName(String psFontName) {
        fontNames.setFontName(psFontName);
    }

    protected void checkFilePath(String path) {
        if (path != null && !FontConstants.BUILTIN_FONTS_14.contains(path) && !FileUtil.fileExists(path)) {
            throw new IOException(IOException.FontFile1NotFound).setMessageParams(path);
        }
    }

    protected void fixSpaceIssue() {
        Glyph space = unicodeToGlyph.get(32);
        if (space != null) {
            codeToGlyph.put(space.getCode(), space);
        }
    }
}
